rm -f  CMakeCache.txt
rm -rf CMakeFiles
rm -f Makefile
rm -rf bin_dsp
rm -f cmake_install.cmake