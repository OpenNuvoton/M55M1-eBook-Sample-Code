README
======

Python scripts to generate C arrays used in implementation of some algorithms.
