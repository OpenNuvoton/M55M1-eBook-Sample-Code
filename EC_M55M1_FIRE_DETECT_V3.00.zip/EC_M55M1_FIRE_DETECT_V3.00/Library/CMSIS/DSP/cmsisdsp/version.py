# Python wrapper version
__version__ = "1.9.9"
