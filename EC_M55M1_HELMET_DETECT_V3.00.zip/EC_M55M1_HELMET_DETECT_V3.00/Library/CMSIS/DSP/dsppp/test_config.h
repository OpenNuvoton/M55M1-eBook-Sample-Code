#ifndef TEST_CONFIG_H
#define TEST_CONFIG_H


#define POOL_ALLOCATOR
//#define ONLY_BENCHMARKS

#define DOT_TEST
#define F32_DT
#define DYNAMIC_TEST


#endif

