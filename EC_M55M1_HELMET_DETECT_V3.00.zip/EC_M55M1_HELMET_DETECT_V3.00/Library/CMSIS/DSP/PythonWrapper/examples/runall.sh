#!/usr/bin/env bash

set -e

python testdistance.py 
python testdsp6.py 
python testdsp5.py  
python example_1_10.py
python example_1_6.py
python example_1_9.py

