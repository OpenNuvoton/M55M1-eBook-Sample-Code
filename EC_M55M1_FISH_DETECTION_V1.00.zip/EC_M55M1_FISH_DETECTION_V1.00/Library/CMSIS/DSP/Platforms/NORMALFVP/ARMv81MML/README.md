# README

Options to use with the FVP

-C cpu0.SECEXT=1 -C fvp_mps2.mps2_visualisation.disable-visualisation=1 -q -C cpu0.MVE=2 -C cpu0.semihosting-enable=1 -a cpu0=Testing 