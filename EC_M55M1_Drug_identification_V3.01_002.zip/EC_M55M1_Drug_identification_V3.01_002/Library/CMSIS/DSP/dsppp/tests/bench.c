#include "bench.h"

uint32_t start_time, stop_time, cycle_count;
