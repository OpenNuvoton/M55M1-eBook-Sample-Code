function writeVersionDropdown() {}
