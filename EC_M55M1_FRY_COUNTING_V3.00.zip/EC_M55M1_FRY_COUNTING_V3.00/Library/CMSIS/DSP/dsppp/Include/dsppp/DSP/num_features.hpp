// -*- C++ -*-
/** @file */ 
#pragma once 

/*

vreduce is going from vector accumulator to scalar accumulator
from_accumulator is going from scalar accumulator to scalar datatype


*/

#include "q7.hpp"
#include "q15.hpp"
