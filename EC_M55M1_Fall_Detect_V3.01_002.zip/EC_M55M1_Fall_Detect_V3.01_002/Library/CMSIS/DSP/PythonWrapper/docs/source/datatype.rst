Datatype
========

.. autodata:: cmsisdsp.datatype.F64
.. autodata:: cmsisdsp.datatype.F32
.. autodata:: cmsisdsp.datatype.F16
.. autodata:: cmsisdsp.datatype.Q31
.. autodata:: cmsisdsp.datatype.Q15
.. autodata:: cmsisdsp.datatype.Q7


.. autofunction:: cmsisdsp.datatype.convert
