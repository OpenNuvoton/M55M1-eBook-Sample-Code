#ifndef IPSS_BENCH_H
#define IPSS_BENCH_H 

#ifdef   __cplusplus
extern "C"
{
#endif

void start_ipss_measurement();
void stop_ipss_measurement();

#ifdef   __cplusplus
}
#endif

#endif
